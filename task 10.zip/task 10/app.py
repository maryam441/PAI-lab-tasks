from flask import Flask, render_template, request, jsonify
import random
import time
import os

app = Flask(__name__)

# Configure upload folder
app.config['UPLOAD_FOLDER'] = 'static/uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

hospital_info = {
    "departments": ["Cardiology", "Neurology", "Oncology", "Pediatrics", "Orthopedics", "Emergency", "Radiology", "General Surgery"],
    "doctors": {
        "Cardiology": ["Dr. Smith", "Dr. Johnson", "Dr. Lee"],
        "Neurology": ["Dr. Brown", "Dr. Davis"],
        "Oncology": ["Dr. Wilson", "Dr. Taylor"],
        "Pediatrics": ["Dr. Miller", "Dr. Anderson"],
        "Orthopedics": ["Dr. Thomas", "Dr. White"],
        "Emergency": ["Dr. Harris", "Dr. Martin"],
        "Radiology": ["Dr. Garcia", "Dr. Martinez"],
        "General Surgery": ["Dr. Robinson", "Dr. Clark"]
    },
    "services": ["Emergency Care", "Inpatient Services", "Outpatient Services", "Surgical Services", "Diagnostic Imaging", "Laboratory Services", "Pharmacy", "Physical Therapy"],
    "visiting_hours": {
        "General": "10:00 AM - 8:00 PM",
        "ICU": "11:00 AM - 12:00 PM and 5:00 PM - 6:00 PM",
        "Pediatrics": "10:00 AM - 7:00 PM"
    },
    "contact": {
        "phone": "+1 (555) 123-4567",
        "email": "info@citygeneralhospital.com",
        "address": "123 Medical Center Drive, Healthville, HV 12345"
    },
    "emergency": "911 or +1 (555) 987-6543",
    "background_image": "hospital-background.jpg"
}

responses = {
    "greeting": ["Hello! How can I assist you at City General Hospital?", "Hi there! What would you like to know today?"],
    "departments": ["We offer the following departments: {}.", "<img src='static/images/hospital-departments.jpg' width='200'><br>We offer these departments: {}."],
    "doctors": ["Doctors in {}: {}.", "<img src='static/images/{}-doctors.jpg' width='200'><br>Our {} specialists: {}."],
    "services": ["Our services include: {}.", "<img src='static/images/hospital-services.jpg' width='200'><br>We provide these services: {}."],
    "visiting_hours": ["Visiting Hours:\nGeneral - {}\nICU - {}\nPediatrics - {}", "<img src='static/images/visiting-hours.jpg' width='200'><br>Visiting Hours:<br>General - {}<br>ICU - {}<br>Pediatrics - {}"],
    "contact": ["Phone: {}\nEmail: {}\nAddress: {}", "<img src='static/images/hospital-location.jpg' width='200'><br>Contact us:<br>Phone: {}<br>Email: {}<br>Address: {}"],
    "emergency": ["In case of emergency, call: {}", "<img src='static/images/emergency-sign.jpg' width='200'><br>Emergency contact: {}"],
    "fallback": ["Sorry, I didn't understand that. Please ask about departments, doctors, services, contact, etc."],
    "goodbye": ["Thank you! Stay healthy.", "<img src='static/images/thank-you.jpg' width='200'><br>Thank you! Stay healthy."]
}

@app.route('/')
def home():
    return render_template('index.html', background_image=hospital_info['background_image'])

@app.route('/ask', methods=['POST'])
def ask():
    user_message = request.get_json().get('message', '').lower()
    bot_response = generate_response(user_message)
    time.sleep(random.uniform(0.1, 0.3))
    return jsonify({'response': bot_response})

def generate_response(user_input):
    if any(word in user_input for word in ['hi', 'hello', 'hey']):
        return random.choice(responses["greeting"])
    elif 'department' in user_input:
        return responses["departments"][1].format(", ".join(hospital_info["departments"]))
    elif 'doctor' in user_input:
        for dept in hospital_info["doctors"]:
            if dept.lower() in user_input:
                return responses["doctors"][1].format(dept.lower(), dept, ", ".join(hospital_info["doctors"][dept]))
        return "Please mention the department to list doctors."
    elif 'service' in user_input:
        return responses["services"][1].format(", ".join(hospital_info["services"]))
    elif 'visit' in user_input or 'hours' in user_input:
        v = hospital_info["visiting_hours"]
        return responses["visiting_hours"][1].format(v["General"], v["ICU"], v["Pediatrics"])
    elif any(x in user_input for x in ['contact', 'phone', 'email', 'address']):
        c = hospital_info["contact"]
        return responses["contact"][1].format(c["phone"], c["email"], c["address"])
    elif 'emergency' in user_input:
        return responses["emergency"][1].format(hospital_info["emergency"])
    elif any(x in user_input for x in ['bye', 'thank']):
        return random.choice(responses["goodbye"])
    else:
        return random.choice(responses["fallback"])

if __name__ == '__main__':
    app.run(debug=True)