from flask import Flask, render_template, request, jsonify
import json
import random
import string
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)

# Load intents
with open('intents.json', 'r') as file:
    intents = json.load(file)

# Preprocess data
tags = []
patterns = []
responses = {}

for intent in intents:
    tag = intent['tag']
    tags.append(tag)
    responses[tag] = intent['responses']
    for pattern in intent['patterns']:
        patterns.append((pattern.lower(), tag))

# Create TF-IDF vectorizer
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform([p[0] for p in patterns])

def get_response(user_input):
    user_input = user_input.lower()
    
    # Vectorize user input
    input_vec = vectorizer.transform([user_input])
    
    # Calculate similarity
    similarities = cosine_similarity(input_vec, X)
    max_sim = similarities.max()
    
    if max_sim > 0.5:  # Threshold for matching
        best_match_idx = similarities.argmax()
        best_tag = patterns[best_match_idx][1]
        return random.choice(responses[best_tag])
    else:
        return "I'm not sure I understand. Could you rephrase that or ask about something else related to mental health?"

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get_response', methods=['POST'])
def chat():
    user_input = request.form['user_input']
    bot_response = get_response(user_input)
    return jsonify({'response': bot_response})

if __name__ == '__main__':
    app.run(debug=True)