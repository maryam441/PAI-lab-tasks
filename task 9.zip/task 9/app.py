from flask import Flask, render_template, request
from transformers import pipeline

app = Flask(__name__)

# Initialize text generator
text_generator = pipeline(
    "text-generation",
    model="gpt2",
    device=-1  # Use CPU if GPU not available
)

@app.route('/', methods=['GET', 'POST'])
def home():
    result = ""
    if request.method == 'POST':
        input_text = request.form.get('text', '').strip()
        if input_text:
            try:
                result = text_generator(
                    input_text,
                    max_length=100,
                    num_return_sequences=1,
                    temperature=0.7,
                    top_p=0.9,
                    repetition_penalty=1.2
                )[0]['generated_text']
            except Exception as e:
                result = f"Error generating text: {str(e)}"
    return render_template('index.html', result=result)

if __name__ == '__main__':
    app.run(debug=True)